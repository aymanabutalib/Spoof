# SpoofifyPro - Advanced Telegram Bot

A sophisticated Telegram bot for privacy and security services with multi-language support and cryptocurrency payments.

## 🌟 Features

### 🌍 Multi-Language Support
- 6 languages: Arabic, English, French, Spanish, Russian, Chinese
- Dynamic language selection on first use
- All messages and buttons adapt to selected language

### 🎛️ Complete Interactive Menus
- **🕵️‍♂️ Spoof Services**: Spoofing and deception services
- **📱 Virtual Numbers**: Virtual numbers from around the world
- **🔢 WhatsApp SIM**: WhatsApp and Telegram activation numbers
- **🔍 Spokeo**: People search and background checks
- **🛠️ Advanced Tools**: Various advanced tools
- **💎 Crypto Payments**: Cryptocurrency payment system
- **ℹ️ Support System**: Comprehensive support system

### 💰 Advanced Payment System
- Support for 7 cryptocurrencies: BTC, ETH, USDT, SOL, LTC, DOGE, BNB
- Minimum top-up: $50
- Fixed payment addresses
- Insufficient balance warnings

### 🌍 Global Coverage
- 50+ countries organized by continents
- Interactive country menus
- Support for all geographical regions

## 🚀 Deployment on Vercel

### Prerequisites
1. Telegram Bot Token from @BotFather
2. Vercel account
3. Domain name (optional but recommended)

### Environment Variables
Set these in your Vercel dashboard:

\`\`\`env
BOT_TOKEN=your_bot_token_here
NEXT_PUBLIC_APP_URL=https://your-domain.vercel.app
NODE_ENV=production
\`\`\`

### Deployment Steps

1. **Clone and Deploy**
   \`\`\`bash
   git clone <your-repo>
   cd spoofify-pro
   vercel --prod
   \`\`\`

2. **Set Environment Variables**
   \`\`\`bash
   vercel env add BOT_TOKEN
   vercel env add NEXT_PUBLIC_APP_URL
   \`\`\`

3. **Deploy with Environment Variables**
   \`\`\`bash
   vercel --prod
   \`\`\`

### Webhook Setup

The bot automatically sets up webhooks when started. The webhook URL will be:
\`\`\`
https://your-domain.vercel.app/api/spoofify/webhook
\`\`\`

### Bot Commands

The bot supports these commands:
- `/start` - Start the bot and select language
- `/menu` - Show main menu
- `/help` - Show help and FAQ
- `/balance` - Check your balance

## 🔧 Configuration

### Crypto Addresses
Update the crypto addresses in `app/api/spoofify/webhook/route.ts`:

\`\`\`typescript
const cryptoAddresses = {
  BTC: {
    address: "your_btc_address",
    network: "Bitcoin Network",
    confirmations: 1
  },
  // ... other cryptocurrencies
}
\`\`\`

### Language Support
Add new languages in the `translations` object:

\`\`\`typescript
const translations = {
  // existing languages...
  de: {
    welcome: "🌍 Bitte wählen Sie Ihre bevorzugte Sprache...",
    // ... other translations
  }
}
\`\`\`

## 📊 Production Considerations

### Database Integration
For production use, replace in-memory storage with a real database:

\`\`\`typescript
// Replace these arrays with database queries
let users: any[] = []
let messages: any[] = []
\`\`\`

Recommended databases:
- Supabase (PostgreSQL)
- MongoDB Atlas
- PlanetScale (MySQL)

### Security Enhancements
1. Add rate limiting
2. Implement user authentication
3. Add input validation
4. Use environment variables for all sensitive data

### Monitoring
1. Add logging service (e.g., LogRocket, Sentry)
2. Monitor webhook failures
3. Track user engagement
4. Monitor payment confirmations

## 🛠️ Development

### Local Development
\`\`\`bash
npm install
npm run dev
\`\`\`

### Testing Webhooks Locally
Use ngrok to expose your local server:
\`\`\`bash
ngrok http 3000
\`\`\`

Then update the webhook URL in your bot settings.

## 📞 Support

For technical support, contact: @Kawalgzaeery

## ⚠️ Legal Notice

This bot is designed for privacy, testing, and security purposes only. Users are responsible for complying with local laws and regulations.
