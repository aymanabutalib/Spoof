#!/usr/bin/env python3
"""
Interactive Test for Bot Makalamat
This script provides an interactive testing interface
"""

import asyncio
from bot_makalamat import *

class InteractiveTest:
    def __init__(self):
        self.current_user_id = 12345  # Test user ID
        self.current_language = 'en'
        
    def setup_test_user(self):
        """Setup a test user"""
        update_user_data(self.current_user_id, {
            'id': self.current_user_id,
            'first_name': 'Test',
            'last_name': 'User',
            'username': 'testuser'
        })
        users_data[self.current_user_id]['selected_language'] = self.current_language
        users_data[self.current_user_id]['balance'] = 0  # Start with no balance
        
    def display_keyboard(self, keyboard, title="Keyboard"):
        """Display keyboard options"""
        print(f"\n📱 {title}:")
        print("-" * 30)
        
        for i, row in enumerate(keyboard.inline_keyboard):
            row_buttons = []
            for button in row:
                row_buttons.append(f"[{button.text}]")
            print(f"   {' '.join(row_buttons)}")
        
        print("-" * 30)
    
    def test_language_selection(self):
        """Test language selection flow"""
        print("\n🌍 Testing Language Selection...")
        
        keyboard = create_language_keyboard()
        self.display_keyboard(keyboard, "Language Selection")
        
        # Test each language
        languages = ['ar', 'en', 'fr', 'es', 'ru', 'cn']
        for lang in languages:
            users_data[self.current_user_id]['selected_language'] = lang
            welcome_text = get_translation(self.current_user_id, 'welcome')
            print(f"   {lang.upper()}: {welcome_text[:50]}...")
    
    def test_main_menu(self):
        """Test main menu"""
        print("\n🏠 Testing Main Menu...")
        
        keyboard = create_main_menu_keyboard()
        self.display_keyboard(keyboard, "Main Menu")
        
        main_menu_text = get_translation(self.current_user_id, 'main_menu')
        print(f"\nMenu Text: {main_menu_text}")
    
    def test_virtual_number_flow(self):
        """Test virtual number complete flow"""
        print("\n📱 Testing Virtual Number Flow...")
        
        # Step 1: Virtual number menu
        keyboard = create_countries_keyboard("country")
        self.display_keyboard(keyboard, "Virtual Number - Countries")
        
        # Step 2: Other countries
        keyboard = create_continents_keyboard()
        self.display_keyboard(keyboard, "Continents Selection")
        
        # Step 3: Europe countries
        keyboard = create_continent_countries_keyboard("europe")
        self.display_keyboard(keyboard, "European Countries")
        
        # Step 4: Insufficient balance
        keyboard = create_insufficient_balance_keyboard()
        self.display_keyboard(keyboard, "Insufficient Balance")
        
        insufficient_text = get_translation(self.current_user_id, 'insufficient_balance')
        print(f"\nInsufficient Balance Text: {insufficient_text}")
    
    def test_topup_flow(self):
        """Test complete top-up flow"""
        print("\n💎 Testing Top-up Flow...")
        
        # Step 1: Amount selection
        keyboard = create_topup_keyboard()
        self.display_keyboard(keyboard, "Top-up Amounts")
        
        # Step 2: Crypto selection
        keyboard = create_crypto_keyboard()
        self.display_keyboard(keyboard, "Cryptocurrency Selection")
        
        # Step 3: Payment details for BTC
        print("\n💰 Payment Details Example (BTC, $100):")
        print("-" * 40)
        
        crypto_info = CRYPTO_ADDRESSES['BTC']
        amount = 100
        crypto_amount = round(amount / crypto_info['price'], 8)
        
        payment_text = f"""💰 Renewal

✅ Payment Method: BTC
🌐 Network: {crypto_info['network']}
💵 Amount: ${amount}

📤 Send to the address below:

{crypto_info['address']}

💸 Requested Value: {crypto_amount} BTC
📊 (Current Exchange Rate: ${crypto_info['price']:,.2f})

⏳ Address valid for 1 hour.
⚠️ Amount may vary slightly due to price fluctuations."""
        
        print(payment_text)
        
        keyboard = create_payment_keyboard()
        self.display_keyboard(keyboard, "Payment Confirmation")
    
    def test_tools_menu(self):
        """Test tools menu"""
        print("\n🛠️ Testing Tools Menu...")
        
        keyboard = create_tools_keyboard()
        self.display_keyboard(keyboard, "Tools Menu")
        
        # Test tool descriptions
        print("\n📝 Tool Descriptions:")
        for tool_id, descriptions in TOOL_DESCRIPTIONS.items():
            en_desc = descriptions.get('en', 'No description')
            print(f"   {tool_id}: {en_desc[:60]}...")
    
    def test_spokeo_menu(self):
        """Test Spokeo menu"""
        print("\n🔍 Testing Spokeo Menu...")
        
        keyboard = create_spokeo_keyboard()
        self.display_keyboard(keyboard, "Spokeo Services")
        
        spokeo_text = get_spokeo_description(self.current_user_id)
        print(f"\nSpokeo Description: {spokeo_text[:100]}...")
    
    def test_support_menu(self):
        """Test support menu"""
        print("\n📞 Testing Support Menu...")
        
        keyboard = create_support_keyboard()
        self.display_keyboard(keyboard, "Support Menu")
        
        support_text = get_support_text(self.current_user_id)
        print(f"\nSupport Text: {support_text[:100]}...")
    
    def test_user_balance_operations(self):
        """Test user balance operations"""
        print("\n💰 Testing Balance Operations...")
        
        # Initial balance
        balance = get_user_balance(self.current_user_id)
        print(f"Initial Balance: ${balance}")
        
        # Add balance
        update_user_balance(self.current_user_id, 100.0)
        new_balance = get_user_balance(self.current_user_id)
        print(f"After adding $100: ${new_balance}")
        
        # Test balance status
        status = get_translation(self.current_user_id, 'balance_sufficient' if new_balance >= 50 else 'balance_low')
        print(f"Balance Status: {status}")
    
    def run_interactive_test(self):
        """Run complete interactive test"""
        print("🧪 Bot Makalamat - Interactive Test Suite")
        print("=" * 50)
        
        # Setup test user
        self.setup_test_user()
        print(f"✅ Test user setup complete (ID: {self.current_user_id})")
        
        # Run all tests
        self.test_language_selection()
        self.test_main_menu()
        self.test_virtual_number_flow()
        self.test_topup_flow()
        self.test_tools_menu()
        self.test_spokeo_menu()
        self.test_support_menu()
        self.test_user_balance_operations()
        
        print("\n" + "=" * 50)
        print("✅ Interactive test completed successfully!")
        print("🚀 Bot Makalamat is ready for live testing!")

def main():
    """Main interactive test function"""
    tester = InteractiveTest()
    tester.run_interactive_test()

if __name__ == "__main__":
    main()
