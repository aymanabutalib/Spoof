#!/bin/bash

echo "🧪 Bot Makalamat - Complete Test Suite"
echo "======================================"

# Check Python installation
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed"
    exit 1
fi

echo "✅ Python 3 found: $(python3 --version)"

# Check if bot file exists
if [ ! -f "bot_makalamat.py" ]; then
    echo "❌ bot_makalamat.py not found"
    exit 1
fi

echo "✅ Bot file found"

# Install requirements if needed
echo "📦 Checking requirements..."
pip3 install python-telegram-bot --quiet

# Run syntax check
echo "🔍 Running syntax check..."
python3 -m py_compile bot_makalamat.py
if [ $? -eq 0 ]; then
    echo "✅ Syntax check passed"
else
    echo "❌ Syntax errors found"
    exit 1
fi

# Run comprehensive tests
echo "🧪 Running comprehensive tests..."
python3 test_bot_makalamat.py

# Run interactive tests
echo "🎮 Running interactive tests..."
python3 interactive_test.py

echo ""
echo "🏁 All tests completed!"
echo "🚀 Bot Makalamat is ready to run!"
echo ""
echo "To start the bot:"
echo "python3 bot_makalamat.py"
