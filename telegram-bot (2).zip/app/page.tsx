"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Bot, MessageCircle, Users, Play, Square, Shield, Globe, CheckCircle, AlertCircle } from "lucide-react"

export default function SpoofifyProDashboard() {
  const [botInfo, setBotInfo] = useState<any>(null)
  const [isRunning, setIsRunning] = useState(false)
  const [stats, setStats] = useState<any>({})
  const [loading, setLoading] = useState(false)
  const [deploymentStatus, setDeploymentStatus] = useState<string>("")
  const [diagnostics, setDiagnostics] = useState<any>(null)
  const [logs, setLogs] = useState<any[]>([])
  const [testChatId, setTestChatId] = useState("")

  const setupBot = async () => {
    setLoading(true)
    setDeploymentStatus("Setting up bot...")

    try {
      const response = await fetch("/api/spoofify/setup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token: process.env.NEXT_PUBLIC_BOT_TOKEN || "7719617243:AAHC5C25eQyjd3ncmA5-SRJfohXaIHIr2BY",
        }),
      })

      const data = await response.json()
      if (data.success) {
        setBotInfo(data.botInfo)
        setIsRunning(true)
        setDeploymentStatus("✅ SpoofifyPro deployed successfully on Vercel!")

        // Show webhook info
        if (data.webhookUrl) {
          setDeploymentStatus((prev) => prev + `\n🔗 Webhook URL: ${data.webhookUrl}`)
        }
      } else {
        setDeploymentStatus("❌ Error: " + data.error)
      }
    } catch (error) {
      setDeploymentStatus("❌ Connection error")
    }
    setLoading(false)
  }

  const stopBot = async () => {
    try {
      await fetch("/api/spoofify/stop", { method: "POST" })
      setIsRunning(false)
      setBotInfo(null)
      setDeploymentStatus("Bot stopped and webhook removed")
    } catch (error) {
      setDeploymentStatus("Error stopping bot")
    }
  }

  const fetchStats = async () => {
    try {
      const response = await fetch("/api/spoofify/stats")
      const data = await response.json()
      if (data.success) {
        setStats(data.stats || {})
      }
    } catch (error) {
      console.error("Error fetching stats:", error)
    }
  }

  const runDiagnostics = async () => {
    setLoading(true)
    setDeploymentStatus("🔍 Running diagnostics...")

    try {
      const response = await fetch("/api/spoofify/test")
      const data = await response.json()
      setDiagnostics(data)

      if (data.tests?.botInfo?.success && data.tests?.webhook?.success) {
        setDeploymentStatus("✅ All tests passed! Bot should be working.")
      } else {
        setDeploymentStatus("⚠️ Some tests failed. Check diagnostics below.")
      }
    } catch (error) {
      setDeploymentStatus("❌ Diagnostics failed: " + error.message)
    }
    setLoading(false)
  }

  const sendTestMessage = async () => {
    if (!testChatId) {
      alert("Please enter your Telegram Chat ID")
      return
    }

    try {
      const response = await fetch("/api/spoofify/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "send_test_message",
          chatId: testChatId,
        }),
      })

      const result = await response.json()
      if (result.ok) {
        alert("✅ Test message sent successfully!")
      } else {
        alert("❌ Failed to send test message: " + result.description)
      }
    } catch (error) {
      alert("❌ Error: " + error.message)
    }
  }

  const fetchLogs = async () => {
    try {
      const response = await fetch("/api/spoofify/logs")
      const data = await response.json()
      if (data.success) {
        setLogs(data.logs)
      }
    } catch (error) {
      console.error("Error fetching logs:", error)
    }
  }

  useEffect(() => {
    if (isRunning) {
      const interval = setInterval(fetchStats, 10000) // Every 10 seconds
      return () => clearInterval(interval)
    }
  }, [isRunning])

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-3">
            <Shield className="w-10 h-10 text-purple-600" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              SpoofifyPro - Vercel Deployment
            </h1>
          </div>
          <p className="text-gray-600">Advanced Telegram Bot for Privacy & Security Services</p>
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Production Ready
          </Badge>
        </div>

        {/* Deployment Status */}
        {deploymentStatus && (
          <Alert
            className={
              deploymentStatus.includes("✅")
                ? "border-green-200 bg-green-50"
                : deploymentStatus.includes("❌")
                  ? "border-red-200 bg-red-50"
                  : "border-blue-200 bg-blue-50"
            }
          >
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="whitespace-pre-line">{deploymentStatus}</AlertDescription>
          </Alert>
        )}

        {/* Bot Control */}
        <Card className="border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bot className="w-5 h-5 text-purple-600" />
              Production Bot Control
            </CardTitle>
            <CardDescription>Deploy and manage your SpoofifyPro bot on Vercel</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              {!isRunning ? (
                <Button onClick={setupBot} disabled={loading} className="bg-green-600 hover:bg-green-700">
                  <Play className="w-4 h-4 mr-2" />
                  {loading ? "Deploying..." : "Deploy to Production"}
                </Button>
              ) : (
                <Button onClick={stopBot} variant="destructive">
                  <Square className="w-4 h-4 mr-2" />
                  Stop Production Bot
                </Button>
              )}
            </div>

            {/* Environment Variables Info */}
            <div className="p-4 bg-gray-50 rounded-lg">
              <h4 className="font-medium mb-2">Required Environment Variables:</h4>
              <div className="space-y-1 text-sm text-gray-600">
                <div>
                  • <code>BOT_TOKEN</code> - Your Telegram bot token
                </div>
                <div>
                  • <code>NEXT_PUBLIC_APP_URL</code> - Your Vercel app URL
                </div>
                <div>
                  • <code>NODE_ENV=production</code> - Production environment
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Bot Status */}
        {botInfo && (
          <div className="grid md:grid-cols-4 gap-4">
            <Card className="border-green-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  Bot Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Name:</span>
                    <span className="font-medium">{botInfo.first_name}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Username:</span>
                    <span className="font-medium">@{botInfo.username}</span>
                  </div>
                  <Badge variant="default" className="bg-green-100 text-green-800 w-full justify-center">
                    🟢 Live on Vercel
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="border-blue-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <MessageCircle className="w-4 h-4 text-blue-600" />
                  Messages
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">{stats.totalMessages || 0}</div>
                <p className="text-sm text-gray-600">Total interactions</p>
              </CardContent>
            </Card>

            <Card className="border-purple-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users className="w-4 h-4 text-purple-600" />
                  Users
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-purple-600">{stats.totalUsers || 0}</div>
                <p className="text-sm text-gray-600">Registered users</p>
                <div className="text-sm text-green-600 mt-1">{stats.activeUsers || 0} active (24h)</div>
              </CardContent>
            </Card>

            <Card className="border-orange-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Globe className="w-4 h-4 text-orange-600" />
                  Revenue
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-orange-600">${stats.totalBalance || 0}</div>
                <p className="text-sm text-gray-600">Total balance</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Production Features */}
        <Tabs defaultValue="features" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="features">Features</TabsTrigger>
            <TabsTrigger value="deployment">Deployment</TabsTrigger>
            <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="features" className="space-y-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card className="border-red-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">🕵️‍♂️ Spoof Services</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">Fake SMS, calls, caller ID spoofing</p>
                  <Badge variant="secondary" className="mt-2">
                    Premium Feature
                  </Badge>
                </CardContent>
              </Card>

              <Card className="border-green-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">📱 Virtual Numbers</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">50+ countries, real-time SMS/calls</p>
                  <Badge variant="secondary" className="mt-2">
                    Global Coverage
                  </Badge>
                </CardContent>
              </Card>

              <Card className="border-blue-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">🔢 WhatsApp SIM</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">Instant WhatsApp/Telegram activation</p>
                  <Badge variant="secondary" className="mt-2">
                    High Success Rate
                  </Badge>
                </CardContent>
              </Card>

              <Card className="border-purple-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">🔍 Spokeo Search</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">Advanced people search & OSINT</p>
                  <Badge variant="secondary" className="mt-2">
                    Professional Grade
                  </Badge>
                </CardContent>
              </Card>

              <Card className="border-yellow-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">🛠️ Advanced Tools</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">HLR, CNAM, image editor, fake data</p>
                  <Badge variant="secondary" className="mt-2">
                    Developer Tools
                  </Badge>
                </CardContent>
              </Card>

              <Card className="border-indigo-200">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">💎 Crypto Payments</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">7 cryptocurrencies, auto-detection</p>
                  <Badge variant="secondary" className="mt-2">
                    Secure & Anonymous
                  </Badge>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="deployment" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Vercel Deployment Guide</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                      1
                    </div>
                    <div>
                      <h4 className="font-medium">Environment Variables</h4>
                      <p className="text-sm text-gray-600">Set BOT_TOKEN and NEXT_PUBLIC_APP_URL in Vercel dashboard</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                      2
                    </div>
                    <div>
                      <h4 className="font-medium">Webhook Setup</h4>
                      <p className="text-sm text-gray-600">Automatic webhook configuration on deployment</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                      3
                    </div>
                    <div>
                      <h4 className="font-medium">Production Ready</h4>
                      <p className="text-sm text-gray-600">Optimized for high-traffic and reliability</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="monitoring" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Performance Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">Response Time</span>
                      <Badge variant="outline">~200ms</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Uptime</span>
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        99.9%
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Error Rate</span>
                      <Badge variant="outline">0.1%</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>System Health</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Webhook Status</span>
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Active
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Database</span>
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Connected
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Payment System</span>
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Operational
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Production Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium mb-2">Supported Languages</h4>
                    <div className="flex flex-wrap gap-2">
                      {["🇸🇦 Arabic", "🇺🇸 English", "🇫🇷 French", "🇪🇸 Spanish", "🇷🇺 Russian", "🇨🇳 Chinese"].map(
                        (lang) => (
                          <Badge key={lang} variant="secondary">
                            {lang}
                          </Badge>
                        ),
                      )}
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Payment Methods</h4>
                    <div className="flex flex-wrap gap-2">
                      {["BTC", "ETH", "USDT", "SOL", "LTC", "DOGE", "BNB"].map((crypto) => (
                        <Badge key={crypto} variant="outline">
                          {crypto}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <h4 className="font-medium text-yellow-800 mb-2">⚠️ Production Notes</h4>
                  <ul className="text-sm text-yellow-700 space-y-1">
                    <li>• Replace in-memory storage with a real database for production</li>
                    <li>• Update crypto addresses with your actual wallet addresses</li>
                    <li>• Implement proper logging and monitoring</li>
                    <li>• Add rate limiting and security measures</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Diagnostics Section */}
        <Card className="border-orange-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">🔧 Bot Diagnostics & Troubleshooting</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Button onClick={runDiagnostics} disabled={loading} variant="outline">
                🔍 Run Diagnostics
              </Button>
              <Button onClick={fetchLogs} variant="outline">
                📋 View Logs
              </Button>
            </div>

            {/* Test Message Section */}
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium mb-2">🧪 Send Test Message</h4>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Your Telegram Chat ID"
                  value={testChatId}
                  onChange={(e) => setTestChatId(e.target.value)}
                  className="flex-1 px-3 py-2 border rounded"
                />
                <Button onClick={sendTestMessage} size="sm">
                  Send Test
                </Button>
              </div>
              <p className="text-xs text-gray-600 mt-1">To get your Chat ID, message @userinfobot on Telegram</p>
            </div>

            {/* Diagnostics Results */}
            {diagnostics && (
              <div className="space-y-3">
                <h4 className="font-medium">Diagnostics Results:</h4>
                <div className="grid md:grid-cols-2 gap-3">
                  <div
                    className={`p-3 rounded border ${diagnostics.tests?.botInfo?.success ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}`}
                  >
                    <div className="font-medium">Bot Token</div>
                    <div className="text-sm">{diagnostics.tests?.botInfo?.success ? "✅ Valid" : "❌ Invalid"}</div>
                    {diagnostics.tests?.botInfo?.data?.username && (
                      <div className="text-xs text-gray-600">@{diagnostics.tests.botInfo.data.username}</div>
                    )}
                  </div>

                  <div
                    className={`p-3 rounded border ${diagnostics.tests?.webhook?.success ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}`}
                  >
                    <div className="font-medium">Webhook</div>
                    <div className="text-sm">{diagnostics.tests?.webhook?.success ? "✅ Active" : "❌ Failed"}</div>
                    {diagnostics.tests?.webhook?.data?.url && (
                      <div className="text-xs text-gray-600 break-all">{diagnostics.tests.webhook.data.url}</div>
                    )}
                  </div>
                </div>

                {/* Environment Variables */}
                <div className="p-3 bg-gray-50 rounded">
                  <h5 className="font-medium mb-2">Environment Variables:</h5>
                  <div className="text-sm space-y-1">
                    <div>VERCEL_URL: {diagnostics.environment?.VERCEL_URL || "❌ Not set"}</div>
                    <div>NEXT_PUBLIC_APP_URL: {diagnostics.environment?.NEXT_PUBLIC_APP_URL || "❌ Not set"}</div>
                    <div>NODE_ENV: {diagnostics.environment?.NODE_ENV || "❌ Not set"}</div>
                  </div>
                </div>
              </div>
            )}

            {/* Logs */}
            {logs.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-medium">Recent Logs:</h4>
                <div className="max-h-60 overflow-y-auto bg-gray-50 p-3 rounded text-sm font-mono">
                  {logs.slice(-10).map((log, index) => (
                    <div key={index} className="mb-1">
                      <span className="text-gray-500">{log.timestamp}</span> - {log.message}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Start Guide */}
        <Card>
          <CardHeader>
            <CardTitle>🚀 Quick Start Guide</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">1. Get Bot Token</h4>
                <p className="text-sm text-gray-600">
                  Message @BotFather on Telegram to create your bot and get the token
                </p>
              </div>
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">2. Deploy to Vercel</h4>
                <p className="text-sm text-gray-600">Click "Deploy to Production" and set your environment variables</p>
              </div>
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">3. Test Your Bot</h4>
                <p className="text-sm text-gray-600">Search for your bot on Telegram and send /start to begin</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
