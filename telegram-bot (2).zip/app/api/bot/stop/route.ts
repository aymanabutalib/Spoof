import { NextResponse } from "next/server"

export async function POST() {
  try {
    // إيقاف البوت (إزالة المتغيرات)
    // في التطبيق الحقيقي، يمكنك إزالة الـ webhook هنا

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: "خطأ في إيقاف البوت",
    })
  }
}
