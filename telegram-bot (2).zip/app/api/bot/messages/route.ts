import { NextResponse } from "next/server"

// في التطبيق الحقيقي، استخدم قاعدة بيانات
let messages: any[] = []

export async function GET() {
  return NextResponse.json({
    success: true,
    messages: messages,
  })
}

export async function POST(request: Request) {
  try {
    const message = await request.json()
    messages.push({
      ...message,
      timestamp: Date.now(),
    })

    // الاحتفاظ بآخر 100 رسالة فقط
    if (messages.length > 100) {
      messages = messages.slice(-100)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: "خطأ في حفظ الرسالة",
    })
  }
}
