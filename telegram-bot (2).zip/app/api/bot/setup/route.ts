import { type NextRequest, NextResponse } from "next/server"

let botToken: string | null = null
let botInfo: any = null

export async function POST(request: NextRequest) {
  try {
    const { token } = await request.json()

    if (!token) {
      return NextResponse.json({ success: false, error: "Token مطلوب" })
    }

    // التحقق من صحة التوكن
    const response = await fetch(`https://api.telegram.org/bot${token}/getMe`)
    const data = await response.json()

    if (!data.ok) {
      return NextResponse.json({ success: false, error: "Token غير صحيح" })
    }

    botToken = token
    botInfo = data.result

    // إعداد webhook (اختياري - للإنتاج)
    // const webhookUrl = `${process.env.NEXT_PUBLIC_APP_URL}/api/bot/webhook`
    // await fetch(`https://api.telegram.org/bot${token}/setWebhook`, {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ url: webhookUrl })
    // })

    return NextResponse.json({
      success: true,
      botInfo: data.result,
    })
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: "خطأ في الخادم",
    })
  }
}
