import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const update = await request.json()

    if (update.message) {
      const message = update.message
      const chatId = message.chat.id
      const text = message.text

      // حفظ الرسالة
      await fetch(`${request.nextUrl.origin}/api/bot/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(message),
      })

      // الرد على الرسائل
      let replyText = ""

      if (text === "/start") {
        replyText = `مرحباً ${message.from.first_name}! 👋\n\nأهلاً بك في بوتي. يمكنك استخدام الأوامر التالية:\n/help - للمساعدة\n/info - معلومات البوت`
      } else if (text === "/help") {
        replyText = `الأوامر المتاحة:\n\n/start - بدء المحادثة\n/help - عرض هذه المساعدة\n/info - معلومات عن البوت\n\nيمكنك أيضاً إرسال أي رسالة وسأرد عليك!`
      } else if (text === "/info") {
        replyText = `معلومات البوت:\n\n🤖 اسم البوت: بوت تليجرام\n📅 تاريخ الإنشاء: ${new Date().toLocaleDateString("ar")}\n💻 تم إنشاؤه باستخدام Next.js`
      } else if (text?.startsWith("/")) {
        replyText = `أمر غير معروف. استخدم /help لرؤية الأوامر المتاحة.`
      } else {
        replyText = `شكراً لك على رسالتك: "${text}"\n\nهذا رد تلقائي من البوت! 🤖`
      }

      // إرسال الرد
      if (replyText && process.env.BOT_TOKEN) {
        await fetch(`https://api.telegram.org/bot${process.env.BOT_TOKEN}/sendMessage`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chat_id: chatId,
            text: replyText,
            parse_mode: "HTML",
          }),
        })
      }
    }

    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ ok: false })
  }
}
