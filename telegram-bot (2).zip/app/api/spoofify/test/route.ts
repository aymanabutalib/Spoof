import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const botToken = process.env.BOT_TOKEN || "7719617243:AAHC5C25eQyjd3ncmA5-SRJfohXaIHIr2BY"

  try {
    console.log("🧪 Starting bot diagnostics...")

    // Test 1: Bot token validity
    console.log("Test 1: Checking bot token...")
    const botResponse = await fetch(`https://api.telegram.org/bot${botToken}/getMe`)
    const botData = await botResponse.json()

    // Test 2: Webhook info
    console.log("Test 2: Checking webhook...")
    const webhookResponse = await fetch(`https://api.telegram.org/bot${botToken}/getWebhookInfo`)
    const webhookData = await webhookResponse.json()

    // Test 3: Bot commands
    console.log("Test 3: Checking bot commands...")
    const commandsResponse = await fetch(`https://api.telegram.org/bot${botToken}/getMyCommands`)
    const commandsData = await commandsResponse.json()

    // Test 4: Send test message (if chat_id provided)
    const url = new URL(request.url)
    const testChatId = url.searchParams.get("chat_id")
    let testMessageResult = null

    if (testChatId) {
      console.log("Test 4: Sending test message...")
      const testMessageResponse = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: testChatId,
          text: "🧪 Test message from SpoofifyPro!\n\nIf you see this, the bot is working correctly! ✅",
          parse_mode: "HTML",
        }),
      })
      testMessageResult = await testMessageResponse.json()
    }

    const diagnostics = {
      timestamp: new Date().toISOString(),
      botToken: botToken.substring(0, 10) + "...",
      tests: {
        botInfo: {
          success: botData.ok,
          data: botData.ok ? botData.result : botData,
          error: !botData.ok ? botData.description : null,
        },
        webhook: {
          success: webhookData.ok,
          data: webhookData.ok ? webhookData.result : webhookData,
          error: !webhookData.ok ? webhookData.description : null,
        },
        commands: {
          success: commandsData.ok,
          data: commandsData.ok ? commandsData.result : commandsData,
          error: !commandsData.ok ? commandsData.description : null,
        },
        testMessage: testMessageResult
          ? {
              success: testMessageResult.ok,
              data: testMessageResult.ok ? testMessageResult.result : testMessageResult,
              error: !testMessageResult.ok ? testMessageResult.description : null,
            }
          : { skipped: "No chat_id provided" },
      },
      environment: {
        VERCEL_URL: process.env.VERCEL_URL || "Not set",
        NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL || "Not set",
        NODE_ENV: process.env.NODE_ENV || "Not set",
      },
    }

    console.log("🔍 Diagnostics completed:", diagnostics)

    return NextResponse.json(diagnostics)
  } catch (error) {
    console.error("💥 Diagnostics error:", error)
    return NextResponse.json({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString(),
    })
  }
}

export async function POST(request: NextRequest) {
  const { action, chatId } = await request.json()
  const botToken = process.env.BOT_TOKEN || "7719617243:AAHC5C25eQyjd3ncmA5-SRJfohXaIHIr2BY"

  try {
    if (action === "send_test_message" && chatId) {
      const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text: "🧪 Manual test message from SpoofifyPro Dashboard!\n\n✅ Bot is responding correctly!",
          parse_mode: "HTML",
        }),
      })

      const result = await response.json()
      return NextResponse.json(result)
    }

    return NextResponse.json({ error: "Invalid action" })
  } catch (error) {
    return NextResponse.json({ error: error.message })
  }
}
