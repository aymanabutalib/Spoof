import { NextResponse } from "next/server"

// Simple in-memory log storage (use database in production)
let logs: any[] = []

export async function GET() {
  return NextResponse.json({
    success: true,
    logs: logs.slice(-50), // Last 50 logs
    total: logs.length,
  })
}

export async function POST(request: Request) {
  try {
    const logEntry = await request.json()

    logs.push({
      ...logEntry,
      timestamp: new Date().toISOString(),
      id: Date.now(),
    })

    // Keep only last 1000 logs
    if (logs.length > 1000) {
      logs = logs.slice(-1000)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ success: false, error: error.message })
  }
}
