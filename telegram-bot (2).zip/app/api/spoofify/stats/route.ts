import { NextResponse } from "next/server"

// In production, replace with real database queries
const users: any[] = []
let messages: any[] = []

export async function GET() {
  try {
    // In production, fetch from database
    return NextResponse.json({
      success: true,
      users: users,
      messages: messages,
      stats: {
        totalUsers: users.length,
        totalMessages: messages.length,
        activeUsers: users.filter((u) => u.lastActivity && Date.now() - u.lastActivity < 24 * 60 * 60 * 1000).length,
        totalBalance: users.reduce((sum, user) => sum + (user.balance || 0), 0),
      },
    })
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: "Failed to fetch stats",
    })
  }
}

export async function POST(request: Request) {
  try {
    const { type, data } = await request.json()

    if (type === "user") {
      const existingIndex = users.findIndex((u) => u.id === data.id)
      if (existingIndex >= 0) {
        users[existingIndex] = { ...users[existingIndex], ...data }
      } else {
        users.push(data)
      }
    } else if (type === "message") {
      messages.push(data)
      // Keep only last 1000 messages
      if (messages.length > 1000) {
        messages = messages.slice(-1000)
      }
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: "Failed to update stats",
    })
  }
}
