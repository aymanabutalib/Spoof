import { NextResponse } from "next/server"

export async function POST() {
  try {
    const botToken = process.env.BOT_TOKEN || "7719617243:AAHC5C25eQyjd3ncmA5-SRJfohXaIHIr2BY"

    // Remove webhook
    await fetch(`https://api.telegram.org/bot${botToken}/deleteWebhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ drop_pending_updates: true }),
    })

    console.log("Bot stopped and webhook removed")

    return NextResponse.json({
      success: true,
      message: "Bot stopped successfully",
    })
  } catch (error) {
    console.error("Stop bot error:", error)
    return NextResponse.json({
      success: false,
      error: "Error stopping bot",
    })
  }
}
