import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { token } = await request.json()
    const botToken = token || process.env.BOT_TOKEN || "7719617243:AAHC5C25eQyjd3ncmA5-SRJfohXaIHIr2BY"

    console.log("🔧 Setting up bot with token:", botToken.substring(0, 10) + "...")

    if (!botToken) {
      return NextResponse.json({ success: false, error: "Bot token is required" })
    }

    // Test bot token first
    console.log("🧪 Testing bot token...")
    const testResponse = await fetch(`https://api.telegram.org/bot${botToken}/getMe`)
    const testData = await testResponse.json()

    if (!testData.ok) {
      console.error("❌ Invalid bot token:", testData)
      return NextResponse.json({ success: false, error: "Invalid bot token: " + testData.description })
    }

    console.log("✅ Bot token valid:", testData.result.username)

    // Get current webhook info
    console.log("🔍 Checking current webhook...")
    const webhookInfoResponse = await fetch(`https://api.telegram.org/bot${botToken}/getWebhookInfo`)
    const webhookInfo = await webhookInfoResponse.json()
    console.log("📡 Current webhook info:", webhookInfo.result)

    // Determine webhook URL
    const webhookUrl = process.env.VERCEL_URL
      ? `https://${process.env.VERCEL_URL}/api/spoofify/webhook`
      : process.env.NEXT_PUBLIC_APP_URL
        ? `${process.env.NEXT_PUBLIC_APP_URL}/api/spoofify/webhook`
        : `https://your-domain.vercel.app/api/spoofify/webhook`

    console.log("🌐 Setting webhook URL:", webhookUrl)

    // Delete existing webhook first
    console.log("🗑️ Removing old webhook...")
    await fetch(`https://api.telegram.org/bot${botToken}/deleteWebhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ drop_pending_updates: true }),
    })

    // Wait a moment
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Set new webhook
    console.log("🔗 Setting new webhook...")
    const webhookResponse = await fetch(`https://api.telegram.org/bot${botToken}/setWebhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: webhookUrl,
        allowed_updates: ["message", "callback_query"],
        drop_pending_updates: true,
        max_connections: 40,
        secret_token: "spoofify_webhook_secret_2024",
      }),
    })

    const webhookData = await webhookResponse.json()
    console.log("📡 Webhook setup result:", webhookData)

    if (!webhookData.ok) {
      console.error("❌ Failed to set webhook:", webhookData)
      return NextResponse.json({
        success: false,
        error: `Failed to set webhook: ${webhookData.description}`,
        webhookUrl: webhookUrl,
        webhookResponse: webhookData,
      })
    }

    // Set bot commands
    console.log("⚙️ Setting bot commands...")
    const commands = [
      { command: "start", description: "🚀 Start the bot and select language" },
      { command: "menu", description: "📋 Show main menu" },
      { command: "help", description: "❓ Show help and FAQ" },
      { command: "balance", description: "💰 Check your balance" },
      { command: "test", description: "🧪 Test bot functionality" },
    ]

    const commandsResponse = await fetch(`https://api.telegram.org/bot${botToken}/setMyCommands`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ commands }),
    })

    const commandsData = await commandsResponse.json()
    console.log("📝 Commands setup result:", commandsData)

    // Test webhook by sending a test message to the bot creator
    console.log("🧪 Testing webhook functionality...")

    // Get webhook info again to confirm
    const finalWebhookInfo = await fetch(`https://api.telegram.org/bot${botToken}/getWebhookInfo`)
    const finalWebhookData = await finalWebhookInfo.json()
    console.log("✅ Final webhook info:", finalWebhookData.result)

    return NextResponse.json({
      success: true,
      botInfo: testData.result,
      webhookUrl: webhookUrl,
      webhookSet: webhookData.ok,
      webhookInfo: finalWebhookData.result,
      commandsSet: commandsData.ok,
      message: "Bot setup completed successfully! Try sending /start to your bot.",
    })
  } catch (error) {
    console.error("💥 Setup error:", error)
    return NextResponse.json({
      success: false,
      error: "Server error during setup: " + error.message,
    })
  }
}
