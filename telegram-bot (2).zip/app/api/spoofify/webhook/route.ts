import { type NextRequest, NextResponse } from "next/server"

// Production-ready data storage (use Supabase/Database in real production)
const users: any[] = []
const messages: any[] = []
const userSessions: { [key: string]: any } = {}

// Enhanced translations with more languages
const translations = {
  ar: {
    welcome: "🌍 يرجى اختيار لغتك المفضلة لبدء استخدام البوت:",
    choose_language: "يرجى اختيار لغتك المفضلة للمتابعة:",
    language_selected: "✅ تم اختيار اللغة العربية بنجاح!",
    main_menu: "القائمة الرئيسية - اختر الخدمة المطلوبة:",
    insufficient_balance:
      "💰 لا يمكن إتمام العملية لأن رصيدك غير كافٍ.\n\n⚠️ كل شيء مدفوع مسبقاً. لا توجد اشتراكات أو رسوم مخفية.",
    virtual_number:
      "📱 رقم افتراضي مؤقت\nهاتف افتراضي / رقم ثاني\n\nرقم افتراضي لاستقبال المكالمات والرسائل عبر الويب، دون الحاجة لبطاقة SIM حقيقية.\nمناسب لحماية الخصوصية ❗\n\nاختر الدولة التي تريد الحصول على رقم منها 👇",
    whats_sim:
      "🔢 Whats SIM\n\nرقم مؤقت يُستخدم لتفعيل خدمات مثل واتساب وتليجرام ولاين، دون الحاجة لبطاقة SIM فعلية. يمكنك أيضاً استقبال مكالمات ورسائل التفعيل عبر الصوت أو النص.\n\nاختر الدولة المطلوبة 👇",
    payment_sent: "✅ تم إرسال الإشعار للدعم الفني. سيتم تفعيل رصيدك خلال دقائق بعد تأكيد المعاملة.",
    back_to_menu: "🔙 العودة للقائمة الرئيسية",
  },
  en: {
    welcome: "🌍 Please choose your preferred language to start using the bot:",
    choose_language: "Please choose your preferred language to continue:",
    language_selected: "✅ English language selected successfully!",
    main_menu: "Main Menu - Choose the required service:",
    insufficient_balance:
      "💰 The transaction cannot be completed because you have insufficient balance.\n\n⚠️ Everything is prepaid. No subscriptions or hidden fees.",
    virtual_number:
      "📱 Temporary Virtual Number\nVirtual Phone / Second Number\n\nA virtual number to receive calls and messages via the web, without the need for a real SIM card.\nSuitable for privacy protection ❗\n\nChoose the country you want to get a number from 👇",
    whats_sim:
      "🔢 Whats SIM\n\nA temporary number used to activate services such as WhatsApp, Telegram, and Line, without the need for a physical SIM card. You can also receive activation calls and messages via voice or text.\n\nSelect the desired country 👇",
    payment_sent:
      "✅ Support team has been notified. Your balance will be activated within minutes after transaction confirmation.",
    back_to_menu: "🔙 Back to Main Menu",
  },
  fr: {
    welcome: "🌍 Veuillez choisir votre langue préférée pour commencer à utiliser le bot:",
    choose_language: "Veuillez choisir votre langue préférée pour continuer:",
    language_selected: "✅ Langue française sélectionnée avec succès!",
    main_menu: "Menu Principal - Choisissez le service requis:",
    insufficient_balance:
      "💰 La transaction ne peut pas être complétée car votre solde est insuffisant.\n\n⚠️ Tout est prépayé. Pas d'abonnements ou de frais cachés.",
    virtual_number:
      "📱 Numéro Virtuel Temporaire\nTéléphone Virtuel / Deuxième Numéro\n\nUn numéro virtuel pour recevoir des appels et des messages via le web, sans avoir besoin d'une vraie carte SIM.\nConvient pour la protection de la vie privée ❗\n\nChoisissez le pays d'où vous voulez obtenir un numéro 👇",
    whats_sim:
      "🔢 Whats SIM\n\nUn numéro temporaire utilisé pour activer des services comme WhatsApp, Telegram et Line, sans avoir besoin d'une carte SIM physique.\n\nSélectionnez le pays désiré 👇",
    payment_sent:
      "✅ L'équipe de support a été notifiée. Votre solde sera activé dans quelques minutes après confirmation de la transaction.",
    back_to_menu: "🔙 Retour au Menu Principal",
  },
  es: {
    welcome: "🌍 Por favor elige tu idioma preferido para comenzar a usar el bot:",
    choose_language: "Por favor elige tu idioma preferido para continuar:",
    language_selected: "✅ ¡Idioma español seleccionado exitosamente!",
    main_menu: "Menú Principal - Elige el servicio requerido:",
    insufficient_balance:
      "💰 La transacción no se puede completar porque tienes saldo insuficiente.\n\n⚠️ Todo es prepago. Sin suscripciones o tarifas ocultas.",
    virtual_number:
      "📱 Número Virtual Temporal\nTeléfono Virtual / Segundo Número\n\nUn número virtual para recibir llamadas y mensajes vía web, sin necesidad de una tarjeta SIM real.\nAdecuado para protección de privacidad ❗\n\nElige el país del que quieres obtener un número 👇",
    whats_sim:
      "🔢 Whats SIM\n\nUn número temporal usado para activar servicios como WhatsApp, Telegram y Line, sin necesidad de una tarjeta SIM física.\n\nSelecciona el país deseado 👇",
    payment_sent:
      "✅ El equipo de soporte ha sido notificado. Tu saldo será activado en minutos después de la confirmación de la transacción.",
    back_to_menu: "🔙 Volver al Menú Principal",
  },
  ru: {
    welcome: "🌍 Пожалуйста, выберите предпочитаемый язык для начала использования бота:",
    choose_language: "Пожалуйста, выберите предпочитаемый язык для продолжения:",
    language_selected: "✅ Русский язык успешно выбран!",
    main_menu: "Главное Меню - Выберите требуемую услугу:",
    insufficient_balance:
      "💰 Транзакция не может быть завершена из-за недостаточного баланса.\n\n⚠️ Все предоплачено. Никаких подписок или скрытых комиссий.",
    virtual_number:
      "📱 Временный Виртуальный Номер\nВиртуальный Телефон / Второй Номер\n\nВиртуальный номер для получения звонков и сообщений через веб, без необходимости в настоящей SIM-карте.\nПодходит для защиты конфиденциальности ❗\n\nВыберите страну, из которой хотите получить номер 👇",
    whats_sim:
      "🔢 Whats SIM\n\nВременный номер, используемый для активации сервисов типа WhatsApp, Telegram и Line, без необходимости в физической SIM-карте.\n\nВыберите желаемую страну 👇",
    payment_sent:
      "✅ Команда поддержки уведомлена. Ваш баланс будет активирован в течение нескольких минут после подтверждения транзакции.",
    back_to_menu: "🔙 Назад в Главное Меню",
  },
  cn: {
    welcome: "🌍 请选择您的首选语言开始使用机器人:",
    choose_language: "请选择您的首选语言继续:",
    language_selected: "✅ 中文语言选择成功!",
    main_menu: "主菜单 - 选择所需服务:",
    insufficient_balance: "💰 由于余额不足，无法完成交易。\n\n⚠️ 一切都是预付费的。没有订阅或隐藏费用。",
    virtual_number:
      "📱 临时虚拟号码\n虚拟电话/第二号码\n\n通过网络接收电话和短信的虚拟号码，无需真实SIM卡。\n适合隐私保护 ❗\n\n选择您想要获取号码的国家 👇",
    whats_sim: "🔢 Whats SIM\n\n用于激活WhatsApp、Telegram和Line等服务的临时号码，无需物理SIM卡。\n\n选择所需国家 👇",
    payment_sent: "✅ 支持团队已收到通知。您的余额将在交易确认后几分钟内激活。",
    back_to_menu: "🔙 返回主菜单",
  },
}

// Enhanced crypto addresses with network info
const cryptoAddresses = {
  BTC: {
    address: "3GvwS9tnSqp5hSKL5RquGKrxsR16quDdQv",
    network: "Bitcoin Network",
    confirmations: 1,
  },
  ETH: {
    address: "0x2a3489047b085d04c8b9f8a2d7e3f1a6b8c9d0e1",
    network: "Ethereum (ERC20)",
    confirmations: 12,
  },
  USDT: {
    address: "TQn9Y2khEsLJW1ChVWFMSMeRDow5oREqjK",
    network: "TRC20 (Tron)",
    confirmations: 1,
  },
  SOL: {
    address: "7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU",
    network: "Solana",
    confirmations: 1,
  },
  LTC: {
    address: "LTC1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4",
    network: "Litecoin",
    confirmations: 6,
  },
  DOGE: {
    address: "DH5yaieqoZN36fDVciNyRueRGvGLR3mr7L",
    network: "Dogecoin",
    confirmations: 6,
  },
  BNB: {
    address: "0x2a3489047b085d04c8b9f8a2d7e3f1a6b8c9d0e1",
    network: "BNB Smart Chain (BEP20)",
    confirmations: 3,
  },
}

// Enhanced logging system
function logActivity(action: string, userId = 0, data?: any) {
  const timestamp = new Date().toISOString()
  const logMessage = `[${timestamp}] ${action} - User: ${userId}`

  console.log(logMessage, data ? JSON.stringify(data, null, 2) : "")

  // In production, send to external logging service
  // Example: send to Discord webhook, Slack, or logging service
}

// Test webhook endpoint
export async function GET(request: NextRequest) {
  logActivity("WEBHOOK_TEST_GET", 0, { url: request.url })

  return NextResponse.json({
    status: "Webhook is working!",
    timestamp: new Date().toISOString(),
    url: request.url,
    method: "GET",
  })
}

async function sendMessage(chatId: number, text: string, replyMarkup?: any, parseMode = "HTML") {
  const botToken = process.env.BOT_TOKEN || "7719617243:AAHC5C25eQyjd3ncmA5-SRJfohXaIHIr2BY"

  try {
    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: text,
        parse_mode: parseMode,
        reply_markup: replyMarkup,
        disable_web_page_preview: true,
      }),
    })

    const result = await response.json()
    if (!result.ok) {
      console.error("Telegram API Error:", result)
    }
    return result
  } catch (error) {
    console.error("Send message error:", error)
    return { ok: false, error }
  }
}

async function editMessage(chatId: number, messageId: number, text: string, replyMarkup?: any) {
  const botToken = process.env.BOT_TOKEN || "7719617243:AAHC5C25eQyjd3ncmA5-SRJfohXaIHIr2BY"

  try {
    await fetch(`https://api.telegram.org/bot${botToken}/editMessageText`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        message_id: messageId,
        text: text,
        parse_mode: "HTML",
        reply_markup: replyMarkup,
        disable_web_page_preview: true,
      }),
    })
  } catch (error) {
    console.error("Edit message error:", error)
  }
}

function getUserLanguage(userId: number): string {
  const user = users.find((u) => u.id === userId)
  return user?.selectedLanguage || "en"
}

function getTranslation(userId: number, key: string): string {
  const lang = getUserLanguage(userId)
  return (
    translations[lang as keyof typeof translations]?.[key as keyof (typeof translations)["en"]] ||
    translations.en[key as keyof (typeof translations)["en"]]
  )
}

function updateUserBalance(userId: number, amount: number) {
  const userIndex = users.findIndex((u) => u.id === userId)
  if (userIndex >= 0) {
    users[userIndex].balance = (users[userIndex].balance || 0) + amount
    logActivity("BALANCE_UPDATE", userId, { newBalance: users[userIndex].balance, added: amount })
  }
}

function getUserBalance(userId: number): number {
  const user = users.find((u) => u.id === userId)
  return user?.balance || 0
}

export async function POST(request: NextRequest) {
  try {
    // Log all incoming requests
    const userAgent = request.headers.get("user-agent")
    const contentType = request.headers.get("content-type")

    logActivity("WEBHOOK_REQUEST_RECEIVED", 0, {
      userAgent,
      contentType,
      url: request.url,
    })

    const update = await request.json()

    // Log the full update for debugging
    logActivity("TELEGRAM_UPDATE_RECEIVED", 0, {
      updateId: update.update_id,
      hasMessage: !!update.message,
      hasCallback: !!update.callback_query,
      updateType: update.message ? "message" : update.callback_query ? "callback" : "unknown",
    })

    // Rest of your existing code...
    logActivity("WEBHOOK_RECEIVED", 0, { updateType: update.message ? "message" : "callback" })

    if (update.message) {
      const message = update.message
      const chatId = message.chat.id
      const userId = message.from.id
      const text = message.text

      // Store message with enhanced data
      messages.push({
        ...message,
        timestamp: Date.now(),
        processed: true,
      })

      // Store/update user with enhanced data
      const existingUserIndex = users.findIndex((u) => u.id === userId)
      if (existingUserIndex >= 0) {
        users[existingUserIndex] = {
          ...users[existingUserIndex],
          ...message.from,
          lastActivity: Date.now(),
          messageCount: (users[existingUserIndex].messageCount || 0) + 1,
        }
      } else {
        users.push({
          ...message.from,
          balance: 0,
          selectedLanguage: null,
          joinDate: Date.now(),
          lastActivity: Date.now(),
          messageCount: 1,
        })
      }

      logActivity("MESSAGE_RECEIVED", userId, { text: text?.substring(0, 50) })

      // Handle commands
      if (text === "/start") {
        const user = users.find((u) => u.id === userId)
        if (!user?.selectedLanguage) {
          await showLanguageSelection(chatId, userId)
        } else {
          await showMainMenu(chatId, userId)
        }
      } else if (text === "/help") {
        await showHelpMenu(chatId, userId)
      } else if (text === "/balance") {
        const balance = getUserBalance(userId)
        const lang = getUserLanguage(userId)
        const balanceText =
          lang === "ar"
            ? `💰 رصيدك الحالي: $${balance}\n\n${balance < 50 ? "⚠️ رصيدك منخفض. يمكنك الشحن من القائمة الرئيسية." : "✅ رصيدك كافٍ لاستخدام الخدمات."}`
            : `💰 Your current balance: $${balance}\n\n${balance < 50 ? "⚠️ Your balance is low. You can top up from the main menu." : "✅ Your balance is sufficient to use services."}`

        await sendMessage(chatId, balanceText)
      } else if (text === "/menu") {
        await showMainMenu(chatId, userId)
      } else {
        // Handle unknown messages
        const user = users.find((u) => u.id === userId)
        if (user?.selectedLanguage) {
          const unknownText =
            getUserLanguage(userId) === "ar"
              ? "❓ أمر غير معروف. استخدم /menu للعودة للقائمة الرئيسية أو /help للمساعدة."
              : "❓ Unknown command. Use /menu to return to main menu or /help for assistance."
          await sendMessage(chatId, unknownText)
        }
      }
    }

    if (update.callback_query) {
      const callbackQuery = update.callback_query
      const chatId = callbackQuery.message.chat.id
      const messageId = callbackQuery.message.message_id
      const userId = callbackQuery.from.id
      const data = callbackQuery.data

      logActivity("CALLBACK_RECEIVED", userId, { data })

      // Acknowledge callback query
      await fetch(
        `https://api.telegram.org/bot${process.env.BOT_TOKEN || "7719617243:AAHC5C25eQyjd3ncmA5-SRJfohXaIHIr2BY"}/answerCallbackQuery`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            callback_query_id: callbackQuery.id,
          }),
        },
      )

      // Handle language selection
      if (data?.startsWith("lang_")) {
        const selectedLang = data.replace("lang_", "")
        const userIndex = users.findIndex((u) => u.id === userId)
        if (userIndex >= 0) {
          users[userIndex].selectedLanguage = selectedLang
          logActivity("LANGUAGE_SELECTED", userId, { language: selectedLang })
        }

        await editMessage(chatId, messageId, getTranslation(userId, "language_selected"))
        setTimeout(() => showMainMenu(chatId, userId), 1500)
      }

      // Handle main menu selections
      else if (data === "virtual_number") {
        await showVirtualNumberMenu(chatId, userId, messageId)
      } else if (data === "whats_sim") {
        await showWhatsSIMMenu(chatId, userId, messageId)
      } else if (data === "spoof") {
        await showSpoofMenu(chatId, userId, messageId)
      } else if (data === "spokeo") {
        await showSpokeoMenu(chatId, userId, messageId)
      } else if (data === "tools") {
        await showToolsMenu(chatId, userId, messageId)
      } else if (data === "topup") {
        await showTopUpMenu(chatId, userId, messageId)
      } else if (data === "support") {
        await showSupportMenu(chatId, userId, messageId)
      }

      // Handle navigation
      else if (data === "other_countries") {
        await showContinentsMenu(chatId, userId, messageId)
      } else if (data?.startsWith("continent_")) {
        const continent = data.replace("continent_", "")
        await showCountriesByContinent(chatId, userId, messageId, continent)
      }

      // Handle country selections (show insufficient balance)
      else if (data?.startsWith("country_") || data?.startsWith("whats_country_")) {
        await showInsufficientBalance(chatId, userId, messageId)
      }

      // Handle top-up flow
      else if (data?.startsWith("topup_")) {
        const amount = data.replace("topup_", "")
        userSessions[userId] = { ...userSessions[userId], selectedAmount: amount }
        await showCryptoSelection(chatId, userId, messageId, amount)
      } else if (data?.startsWith("crypto_")) {
        const crypto = data.replace("crypto_", "")
        const session = userSessions[userId]
        if (session?.selectedAmount) {
          await showPaymentDetails(chatId, userId, messageId, session.selectedAmount, crypto)
        }
      }

      // Handle payment confirmation
      else if (data === "payment_sent") {
        const session = userSessions[userId]
        if (session?.selectedAmount) {
          logActivity("PAYMENT_REPORTED", userId, session)
          await editMessage(chatId, messageId, getTranslation(userId, "payment_sent"))

          // Notify admin (in production, implement proper notification system)
          const adminNotification = `🔔 Payment Report\n\nUser: ${userId}\nAmount: $${session.selectedAmount}\nCrypto: ${session.selectedCrypto || "Unknown"}\nTime: ${new Date().toISOString()}`
          // Send to admin chat or webhook
        }
      }

      // Handle service selections (show insufficient balance for all)
      else if (data?.startsWith("spoof_") || data?.startsWith("spokeo_") || data?.startsWith("tool_")) {
        await showInsufficientBalance(chatId, userId, messageId)
      }

      // Handle back buttons
      else if (data === "back_main") {
        await showMainMenu(chatId, userId, messageId)
      } else if (data === "back_virtual") {
        await showVirtualNumberMenu(chatId, userId, messageId)
      } else if (data === "back_whats") {
        await showWhatsSIMMenu(chatId, userId, messageId)
      }
    }

    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error("Webhook error:", error)
    logActivity("WEBHOOK_ERROR", 0, { error: error.message })
    return NextResponse.json({ ok: false, error: error.message })
  }
}

async function showLanguageSelection(chatId: number, userId: number) {
  const languageKeyboard = {
    inline_keyboard: [
      [
        { text: "🇸🇦 Arabic 🕌", callback_data: "lang_ar" },
        { text: "🇺🇸 English 🌐", callback_data: "lang_en" },
        { text: "🇫🇷 Français 🇫🇷", callback_data: "lang_fr" },
      ],
      [
        { text: "🇪🇸 Español 🇪🇸", callback_data: "lang_es" },
        { text: "🇷🇺 Русский 🪆", callback_data: "lang_ru" },
        { text: "🇨🇳 中文 🇨🇳", callback_data: "lang_cn" },
      ],
    ],
  }

  await sendMessage(
    chatId,
    "🌍 Please choose your preferred language to start using the bot:\n\nPlease choose your preferred language to continue:",
    languageKeyboard,
  )
}

async function showMainMenu(chatId: number, userId: number, messageId?: number) {
  const mainMenuKeyboard = {
    inline_keyboard: [
      [
        { text: "🕵️‍♂️ Spoof", callback_data: "spoof" },
        { text: "🔢 Whats SIM", callback_data: "whats_sim" },
      ],
      [
        { text: "📱 Virtual Number", callback_data: "virtual_number" },
        { text: "💎 Top Up", callback_data: "topup" },
      ],
      [
        { text: "🔍 Spokeo - Detect People", callback_data: "spokeo" },
        { text: "🛠️ Tools", callback_data: "tools" },
      ],
      [{ text: "ℹ️ Instructions and Support", callback_data: "support" }],
    ],
  }

  const menuText = getTranslation(userId, "main_menu")

  if (messageId) {
    await editMessage(chatId, messageId, menuText, mainMenuKeyboard)
  } else {
    await sendMessage(chatId, menuText, mainMenuKeyboard)
  }
}

async function showVirtualNumberMenu(chatId: number, userId: number, messageId?: number) {
  const countryKeyboard = {
    inline_keyboard: [
      [
        { text: "🇺🇸 America", callback_data: "country_us" },
        { text: "🇬🇧 Britain", callback_data: "country_gb" },
      ],
      [
        { text: "🇩🇪 Germany", callback_data: "country_de" },
        { text: "🇸🇦 Saudi Arabia", callback_data: "country_sa" },
      ],
      [{ text: "🌍 Other countries", callback_data: "other_countries" }],
      [{ text: "⬅️ Back", callback_data: "back_main" }],
    ],
  }

  const text = getTranslation(userId, "virtual_number")

  if (messageId) {
    await editMessage(chatId, messageId, text, countryKeyboard)
  } else {
    await sendMessage(chatId, text, countryKeyboard)
  }
}

async function showWhatsSIMMenu(chatId: number, userId: number, messageId?: number) {
  const countryKeyboard = {
    inline_keyboard: [
      [
        { text: "🇺🇸 America", callback_data: "whats_country_us" },
        { text: "🇬🇧 Britain", callback_data: "whats_country_gb" },
      ],
      [
        { text: "🇩🇪 Germany", callback_data: "whats_country_de" },
        { text: "🇸🇦 Saudi Arabia", callback_data: "whats_country_sa" },
      ],
      [{ text: "🌍 Other Countries", callback_data: "other_countries" }],
      [{ text: "⬅️ Back", callback_data: "back_main" }],
    ],
  }

  const text = getTranslation(userId, "whats_sim")

  if (messageId) {
    await editMessage(chatId, messageId, text, countryKeyboard)
  } else {
    await sendMessage(chatId, text, countryKeyboard)
  }
}

async function showInsufficientBalance(chatId: number, userId: number, messageId?: number) {
  const insufficientKeyboard = {
    inline_keyboard: [
      [{ text: "💎 Top up your balance", callback_data: "topup" }],
      [{ text: "🔙 Back", callback_data: "back_main" }],
    ],
  }

  const text = getTranslation(userId, "insufficient_balance")

  if (messageId) {
    await editMessage(chatId, messageId, text, insufficientKeyboard)
  } else {
    await sendMessage(chatId, text, insufficientKeyboard)
  }
}

async function showTopUpMenu(chatId: number, userId: number, messageId?: number) {
  const topupKeyboard = {
    inline_keyboard: [
      [
        { text: "$50", callback_data: "topup_50" },
        { text: "$100", callback_data: "topup_100" },
        { text: "$200", callback_data: "topup_200" },
      ],
      [
        { text: "$300", callback_data: "topup_300" },
        { text: "$500", callback_data: "topup_500" },
        { text: "$1000", callback_data: "topup_1000" },
      ],
      [{ text: "🔙 Back", callback_data: "back_main" }],
    ],
  }

  const lang = getUserLanguage(userId)
  const topupText =
    lang === "ar"
      ? "💰 تجديد الرصيد\n\nيرجى كتابة أو اختيار المبلغ الذي تريد شحنه (بالدولار).\n🔻 الحد الأدنى للشحن: $50"
      : "💰 Renewal\n\nPlease type or select the amount you want to top up (in dollars).\n🔻 Minimum top-up: $50"

  if (messageId) {
    await editMessage(chatId, messageId, topupText, topupKeyboard)
  } else {
    await sendMessage(chatId, topupText, topupKeyboard)
  }
}

async function showCryptoSelection(chatId: number, userId: number, messageId: number, amount: string) {
  const cryptoKeyboard = {
    inline_keyboard: [
      [
        { text: "BTC", callback_data: "crypto_BTC" },
        { text: "ETH", callback_data: "crypto_ETH" },
        { text: "USDT", callback_data: "crypto_USDT" },
      ],
      [
        { text: "SOL", callback_data: "crypto_SOL" },
        { text: "LTC", callback_data: "crypto_LTC" },
        { text: "DOGE", callback_data: "crypto_DOGE" },
      ],
      [{ text: "BNB", callback_data: "crypto_BNB" }],
      [{ text: "🔙 Back", callback_data: "topup" }],
    ],
  }

  const lang = getUserLanguage(userId)
  const cryptoText =
    lang === "ar"
      ? `✅ المبلغ المحدد: $${amount}\n\n🔜 الآن اختر العملة التي تريد الدفع بها:\n\n💱 ₿ العملات المشفرة\n\nاختر العملة التي تريد الدفع بها:\n👇 اضغط على العملة:`
      : `✅ Amount selected: $${amount}\n\n🔜 Now choose the currency you want to pay with:\n\n💱 ₿ Cryptocurrencies\n\nChoose the currency you want to pay with:\n👇 Click on the currency:`

  await editMessage(chatId, messageId, cryptoText, cryptoKeyboard)
}

async function showPaymentDetails(chatId: number, userId: number, messageId: number, amount: string, crypto: string) {
  const paymentKeyboard = {
    inline_keyboard: [
      [{ text: "✅ Amount sent", callback_data: "payment_sent" }],
      [{ text: "🔙 Return", callback_data: "topup" }],
    ],
  }

  // Store crypto selection in session
  userSessions[userId] = { ...userSessions[userId], selectedCrypto: crypto }

  const cryptoInfo = cryptoAddresses[crypto as keyof typeof cryptoAddresses]
  const address = cryptoInfo.address
  const network = cryptoInfo.network

  // Calculate approximate crypto amount (simplified - in production use real API)
  const cryptoPrices: { [key: string]: number } = {
    BTC: 107198.37,
    ETH: 3456.78,
    USDT: 1.0,
    SOL: 234.56,
    LTC: 123.45,
    DOGE: 0.34,
    BNB: 678.9,
  }

  const cryptoAmount = (Number.parseFloat(amount) / cryptoPrices[crypto]).toFixed(8)

  const lang = getUserLanguage(userId)
  const paymentText =
    lang === "ar"
      ? `💰 تجديد الرصيد\n\n✅ طريقة الدفع: ${crypto}\n🌐 الشبكة: ${network}\n💵 المبلغ: $${amount}\n\n📤 أرسل إلى العنوان أدناه:\n\n<code>${address}</code>\n\n💸 القيمة المطلوبة: ${cryptoAmount} ${crypto}\n📊 (سعر الصرف الحالي: $${cryptoPrices[crypto].toLocaleString()})\n\n⏳ العنوان صالح لمدة ساعة واحدة.\n⚠️ قد يختلف المبلغ قليلاً بسبب تقلبات الأسعار.\n\n🔔 بعد الإرسال، اضغط "تم الإرسال" وسيتم تفعيل رصيدك تلقائياً.`
      : `💰 Renewal\n\n✅ Payment Method: ${crypto}\n🌐 Network: ${network}\n💵 Amount: $${amount}\n\n📤 Send to the address below:\n\n<code>${address}</code>\n\n💸 Requested Value: ${cryptoAmount} ${crypto}\n📊 (Current Exchange Rate: $${cryptoPrices[crypto].toLocaleString()})\n\n⏳ Address valid for 1 hour.\n⚠️ Amount may vary slightly due to price fluctuations.\n\n🔔 After sending, click "Amount sent" and your balance will be activated automatically.`

  await editMessage(chatId, messageId, paymentText, paymentKeyboard)
}

async function showSpoofMenu(chatId: number, userId: number, messageId?: number) {
  const spoofKeyboard = {
    inline_keyboard: [
      [
        { text: "📱 Fake SMS", callback_data: "spoof_sms" },
        { text: "📞 Fake Call", callback_data: "spoof_call" },
      ],
      [
        { text: "🎭 Caller ID Spoof", callback_data: "spoof_caller_id" },
        { text: "📧 Email Spoof", callback_data: "spoof_email" },
      ],
      [{ text: "⬅️ Back", callback_data: "back_main" }],
    ],
  }

  const lang = getUserLanguage(userId)
  const spoofText =
    lang === "ar"
      ? "🕵️‍♂️ خدمات التزييف\n\nاختر خدمة التزييف التي تريد استخدامها:\n\n• رسائل SMS مزيفة - إرسال رسائل نصية مزيفة\n• مكالمات مزيفة - إجراء مكالمات هاتفية مزيفة\n• تزييف هوية المتصل - تغيير هوية المتصل\n• بريد إلكتروني مزيف - إرسال رسائل بريد إلكتروني مزيفة"
      : "🕵️‍♂️ Spoof Services\n\nChoose the spoofing service you want to use:\n\n• Fake SMS - Send fake text messages\n• Fake Call - Make fake phone calls\n• Caller ID Spoof - Change your caller ID\n• Email Spoof - Send spoofed emails"

  if (messageId) {
    await editMessage(chatId, messageId, spoofText, spoofKeyboard)
  } else {
    await sendMessage(chatId, spoofText, spoofKeyboard)
  }
}

async function showSpokeoMenu(chatId: number, userId: number, messageId?: number) {
  const spokeoKeyboard = {
    inline_keyboard: [
      [
        { text: "🔎 People Search", callback_data: "spokeo_people" },
        { text: "☎️ Search by Phone Number", callback_data: "spokeo_phone" },
      ],
      [
        { text: "📄 Criminal and Court Records", callback_data: "spokeo_criminal" },
        { text: "🌐 OSINT and Additional Features", callback_data: "spokeo_osint" },
      ],
      [{ text: "⬅️ Back", callback_data: "back_main" }],
    ],
  }

  const lang = getUserLanguage(userId)
  const spokeoText =
    lang === "ar"
      ? "🔍 Spokeo - خدمة تحديد الهوية المتقدمة\n\n📌 وصف الخدمة:\nSpokeo هو أداة بحث قوية تتيح لك جمع المعلومات الشخصية والعامة عن الأفراد بالاسم أو رقم الهاتف أو البريد الإلكتروني أو العنوان.\n\n✅ النتائج تشمل:\n• معلومات الاتصال وأفراد العائلة والمواقع السكنية وحسابات وسائل التواصل الاجتماعي.\n• السجلات التاريخية والجنائية وقيم العقارات.\n• نتائج سريعة مع دعم فني وخصوصية صارمة.\n\n⚠️ ملاحظة:\nلا يُستخدم للأغراض القانونية (مثل التوظيف أو الإيجار)، وقد تكون بعض البيانات غير دقيقة وفقاً لـ FCRA."
      : "🔍 Spokeo - Advanced Person Identification Service\n\n📌 Service Description:\nSpokeo is a powerful search tool that allows you to gather personal and general information about individuals by name, phone number, email, or address.\n\n✅ Results include:\n• Contact information, family members, residential locations, and social media accounts.\n• Historical and criminal records, and real estate values.\n• Fast results, with technical support and strict privacy.\n\n⚠️ Note:\nNot to be used for legal purposes (such as employment or rental), and some data may be inaccurate according to the FCRA."

  if (messageId) {
    await editMessage(chatId, messageId, spokeoText, spokeoKeyboard)
  } else {
    await sendMessage(chatId, spokeoText, spokeoKeyboard)
  }
}

async function showToolsMenu(chatId: number, userId: number, messageId?: number) {
  const toolsKeyboard = {
    inline_keyboard: [
      [
        { text: "📱 Trash Mobile", callback_data: "tool_trash_mobile" },
        { text: "📧 Trash Mail", callback_data: "tool_trash_mail" },
      ],
      [
        { text: "📞 Call Forward", callback_data: "tool_call_forward" },
        { text: "📲 Phone Checker", callback_data: "tool_phone_checker" },
      ],
      [
        { text: "📡 HLR Lookup", callback_data: "tool_hlr" },
        { text: "🔍 Find Caller Name", callback_data: "tool_cnam" },
      ],
      [
        { text: "🖼️ Image Editor", callback_data: "tool_image_editor" },
        { text: "🕵️ Stalk Scan", callback_data: "tool_stalk_scan" },
      ],
      [{ text: "🧾 Fake Data", callback_data: "tool_fake_data" }],
      [{ text: "🔙 Back", callback_data: "back_main" }],
    ],
  }

  const lang = getUserLanguage(userId)
  const toolsText =
    lang === "ar"
      ? "🛠️ الأدوات المتقدمة المتاحة:\n\n⬇️ اختر الأداة التي تريد عرض تفاصيلها:"
      : "🛠️ Available Advanced Tools:\n\n⬇️ Choose the tool you want to view details for:"

  if (messageId) {
    await editMessage(chatId, messageId, toolsText, toolsKeyboard)
  } else {
    await sendMessage(chatId, toolsText, toolsKeyboard)
  }
}

async function showSupportMenu(chatId: number, userId: number, messageId?: number) {
  const supportKeyboard = {
    inline_keyboard: [
      [{ text: "📩 Message Support", url: "https://t.me/Kawalgzaeery" }],
      [{ text: "🔙 Back", callback_data: "back_main" }],
    ],
  }

  const lang = getUserLanguage(userId)
  const supportText =
    lang === "ar"
      ? `ℹ️ تعليمات المستخدم والدعم\n\n📘 هذا دليل بسيط لاستخدام أبرز خدمات البوت:\n\n📱 رقم افتراضي\nاختر دولتك، ثم استقبل المكالمات أو الرسائل باستخدام رقم رقمي مؤقت.\n\n🔢 Whats SIM\nأرقام لتفعيل واتساب/تليجرام بدون SIM فعلية، بما في ذلك استقبال المكالمات والرسائل.\n\n🛠️ الأدوات\nأدوات متنوعة مثل Trash Mail وفحص الأرقام وCNAM وتحرير الصور وتوليد بيانات وهمية والمزيد.\n\n🔍 Spokeo\nالبحث عن الأشخاص بالاسم أو الرقم أو البريد الإلكتروني. يشمل التقارير العامة والهويات وجهات الاتصال.\n\n💎 شحن الرصيد\nشحن رصيدك بالدولار باستخدام العملات المشفرة. الحد الأدنى 50 دولار والدفع تلقائي.\n\n📞 للتواصل مع الدعم الفني:\n👤 تليجرام: @Kawalgzaeery`
      : `ℹ️ User Instructions & Support\n\n📘 This is a simple guide to using the bot's most prominent services:\n\n📱 Virtual Number\nChoose your country, then receive calls or messages using a temporary digital number.\n\n🔢 Whats SIM\nNumbers to activate WhatsApp/Telegram without a physical SIM, including receiving calls and messages.\n\n🛠️ Tools\nVarious tools such as Trash Mail, number check, CNAM, image editing, generating fake data, and more.\n\n🔍 Spokeo\nSearch for people by name, number, or email. Includes general reports, identities, and contacts.\n\n💎 Top Up Your Balance\nTop up your balance in dollars using cryptocurrencies. The minimum is $50, and payment is automatic.\n\n📞 To contact technical support:\n👤 Telegram: @Kawalgzaeery`

  if (messageId) {
    await editMessage(chatId, messageId, supportText, supportKeyboard)
  } else {
    await sendMessage(chatId, supportText, supportKeyboard)
  }
}

async function showHelpMenu(chatId: number, userId: number) {
  const lang = getUserLanguage(userId)
  const helpText =
    lang === "ar"
      ? `ℹ️ <b>المساعدة والأسئلة الشائعة</b>\n\nمرحباً بك في <b>SpoofifyPro</b> 👋\nإليك دليلك السريع لاستخدام الخدمات المتاحة:\n\n—\n\n<b>📱 رقم افتراضي مؤقت</b>\nاستخدم رقماً حقيقياً بدون بطاقة SIM لتفعيل الخدمات أو استقبال المكالمات والرسائل.\n\n<b>🔢 Whats SIM</b>\nرقم افتراضي مخصص لتفعيل واتساب وتليجرام وغيرها بالرسائل أو المكالمات الصوتية.\n\n<b>🛠️ أدوات متقدمة</b>\nمثل: فحص الأرقام، HLR، هوية المتصل، مولد البيانات الوهمية، والمزيد.\n\n<b>🔍 Spokeo</b>\nأداة قوية للبحث عن الأشخاص بالاسم أو البريد الإلكتروني أو الرقم أو العنوان.\n\n<b>🕵️‍♂️ Spoof</b>\nخدمات التزييف: إرسال SMS مزيف، مكالمات مزيفة، تغيير هوية المتصل، والمزيد.\n\n<b>💎 شحن رصيدك</b>\nاختر مبلغ الشحن واختر العملة الرقمية، واستلم العنوان للدفع.\n\n—\n\n<b>❓ هل يوجد اشتراك شهري؟</b>\nلا. جميع الخدمات مدفوعة مسبقاً فقط.\n❌ لا توجد رسوم مخفية — ❌ لا توجد اشتراكات.\n\n<b>💰 نفد الرصيد؟</b>\nستتلقى رسالة تلقائية مع الخيارات التالية:\n<code>💎 شحن رصيدك</code> أو <code>🔙 العودة</code>\n\n—\n\n<b>📞 الدعم الفني:</b>\nراسلنا عبر: <a href="https://t.me/Kawalgzaeery">@Kawalgzaeery</a>\n\n—\n\n⚠️ قد لا تُستخدم الخدمات لأغراض غير قانونية.\nمصممة للخصوصية والمزح والاختبار وأغراض الأمان فقط ✅`
      : `ℹ️ <b>Help and FAQ</b>\n\nWelcome to <b>SpoofifyPro</b> 👋\nHere's your quick guide to using the available services:\n\n—\n\n<b>📱 Temporary Virtual Number</b>\nUse a real number without a SIM card to activate services or receive calls and messages.\n\n<b>🔢 Whats SIM</b>\nA virtual number dedicated to activating WhatsApp, Telegram, and others with messages or voice calls.\n\n<b>🛠️ Advanced Tools</b>\nSuch as: Number Check, HLR, Caller ID, Fake Data Generator, and more.\n\n<b>🔍 Spokeo</b>\nA powerful tool to search for people by name, email, number, or address.\n\n<b>🕵️‍♂️ Spoof</b>\nSpoofing Services: Sending Fake SMS, Fake Calls, Changing Caller ID, and more.\n\n<b>💎 Top-up Your Balance</b>\nChoose the top-up amount and select the digital currency, and receive the address for payment.\n\n—\n\n<b>❓ Is there a monthly subscription?</b>\nNo. All services are prepaid only.\n❌ No hidden fees — ❌ No subscriptions.\n\n<b>💰 Ran out of credit?</b>\nYou will receive an automatic message with the following options:\n<code>💎 Top up your credit</code> or <code>🔙 Return</code>\n\n—\n\n<b>📞 Technical Support:</b>\nMessage us via: <a href="https://t.me/Kawalgzaeery">@Kawalgzaeery</a>\n\n—\n\n⚠️ The services may not be used for illegal purposes.\nDesigned for privacy, pranks, testing, and security purposes only ✅`

  await sendMessage(chatId, helpText)
}

async function showContinentsMenu(chatId: number, userId: number, messageId: number) {
  const continentsKeyboard = {
    inline_keyboard: [
      [
        { text: "🌎 North America", callback_data: "continent_north_america" },
        { text: "🌍 Europe", callback_data: "continent_europe" },
      ],
      [
        { text: "🌏 Asia", callback_data: "continent_asia" },
        { text: "🌍 Africa", callback_data: "continent_africa" },
      ],
      [{ text: "🌐 Miscellaneous countries", callback_data: "continent_misc" }],
      [{ text: "⬅️ Back", callback_data: "back_virtual" }],
    ],
  }

  const lang = getUserLanguage(userId)
  const text = lang === "ar" ? "🌍 اختر قارة لعرض الدول المتاحة:" : "🌍 Select a continent to view available countries:"

  await editMessage(chatId, messageId, text, continentsKeyboard)
}

async function showCountriesByContinent(chatId: number, userId: number, messageId: number, continent: string) {
  let countriesKeyboard: any
  const backCallback = "other_countries"

  switch (continent) {
    case "north_america":
      countriesKeyboard = {
        inline_keyboard: [
          [
            { text: "🇺🇸 America", callback_data: "country_us" },
            { text: "🇨🇦 Canada", callback_data: "country_ca" },
            { text: "🇲🇽 Mexico", callback_data: "country_mx" },
          ],
          [
            { text: "🇵🇷 Puerto Rico", callback_data: "country_pr" },
            { text: "🇵🇦 Panama", callback_data: "country_pa" },
            { text: "🇯🇲 Jamaica", callback_data: "country_jm" },
          ],
          [{ text: "⬅️ Back", callback_data: backCallback }],
        ],
      }
      break
    case "europe":
      countriesKeyboard = {
        inline_keyboard: [
          [
            { text: "🇫🇷 France", callback_data: "country_fr" },
            { text: "🇮🇹 Italy", callback_data: "country_it" },
            { text: "🇪🇸 Spain", callback_data: "country_es" },
          ],
          [
            { text: "🇷🇺 Russia", callback_data: "country_ru" },
            { text: "🇩🇪 Germany", callback_data: "country_de" },
            { text: "🇹🇷 Turkey", callback_data: "country_tr" },
          ],
          [
            { text: "🇸🇪 Sweden", callback_data: "country_se" },
            { text: "🇳🇴 Norway", callback_data: "country_no" },
            { text: "🇫🇮 Finland", callback_data: "country_fi" },
          ],
          [{ text: "⬅️ Back", callback_data: backCallback }],
        ],
      }
      break
    case "asia":
      countriesKeyboard = {
        inline_keyboard: [
          [
            { text: "🇯🇵 Japan", callback_data: "country_jp" },
            { text: "🇰🇷 South Korea", callback_data: "country_kr" },
            { text: "🇨🇳 China", callback_data: "country_cn" },
          ],
          [
            { text: "🇮🇳 India", callback_data: "country_in" },
            { text: "🇮🇩 Indonesia", callback_data: "country_id" },
            { text: "🇵🇭 Philippines", callback_data: "country_ph" },
          ],
          [
            { text: "🇦🇪 UAE", callback_data: "country_ae" },
            { text: "🇶🇦 Qatar", callback_data: "country_qa" },
            { text: "🇰🇼 Kuwait", callback_data: "country_kw" },
          ],
          [{ text: "⬅️ Back", callback_data: backCallback }],
        ],
      }
      break
    case "africa":
      countriesKeyboard = {
        inline_keyboard: [
          [
            { text: "🇪🇬 Egypt", callback_data: "country_eg" },
            { text: "🇲🇦 Morocco", callback_data: "country_ma" },
            { text: "🇩🇿 Algeria", callback_data: "country_dz" },
          ],
          [
            { text: "🇳🇬 Nigeria", callback_data: "country_ng" },
            { text: "🇿🇦 South Africa", callback_data: "country_za" },
            { text: "🇹🇳 Tunisia", callback_data: "country_tn" },
          ],
          [{ text: "⬅️ Back", callback_data: backCallback }],
        ],
      }
      break
    default:
      countriesKeyboard = {
        inline_keyboard: [
          [
            { text: "🇦🇺 Australia", callback_data: "country_au" },
            { text: "🇳🇿 New Zealand", callback_data: "country_nz" },
            { text: "🇮🇱 Israel", callback_data: "country_il" },
          ],
          [
            { text: "🇧🇷 Brazil", callback_data: "country_br" },
            { text: "🇦🇷 Argentina", callback_data: "country_ar" },
            { text: "🇨🇱 Chile", callback_data: "country_cl" },
          ],
          [{ text: "⬅️ Back", callback_data: backCallback }],
        ],
      }
  }

  const lang = getUserLanguage(userId)
  const text = lang === "ar" ? "🌍 اختر دولة:" : "🌍 Select a country:"

  await editMessage(chatId, messageId, text, countriesKeyboard)
}
